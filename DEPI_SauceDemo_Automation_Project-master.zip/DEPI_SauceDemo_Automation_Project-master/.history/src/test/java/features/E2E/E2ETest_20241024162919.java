package features.E2E;

public class E2ETest {
}
