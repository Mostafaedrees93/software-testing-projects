package features.f2_product_management;

public class ProductDetailsTest {

}
